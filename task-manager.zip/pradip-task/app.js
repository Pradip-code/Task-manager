const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");

const taskRoutes = require("./routes/task.route");

dotenv.config();

const app = express();
app.use(bodyParser.json());

const port = process.env.PORT || 3000;

app.use("/api", taskRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
