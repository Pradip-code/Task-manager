const express = require("express");

const {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
  filterTasksByStatus,
} = require("../controllers/task.controller");

const route = express.Router();

route.get("/tasks",  getTasks);
route.post("/tasks", createTask);
route.put("/tasks/:id", updateTask);
route.delete("/tasks/:id", deleteTask);
route.get("/tasks/:status", filterTasksByStatus);

module.exports = route;
