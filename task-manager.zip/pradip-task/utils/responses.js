const successResponse = (res, statusCode, message, data = {}) => {
  res.status(statusCode).json({
    message,
    data,
  });
};

const errorResponse = (res, statusCode, message) => {
  res.status(statusCode).json({
    error: message,
  });
};

module.exports = { successResponse, errorResponse };
