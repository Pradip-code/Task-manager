const fs = require("fs");
const path = require("path");

const tasksFilePath = path.join(__dirname, "../tasks.json");

const readTasksFromFile = () => {
  if (!fs.existsSync(tasksFilePath)) {
    fs.writeFileSync(tasksFilePath, JSON.stringify([]));
  }
  const data = fs.readFileSync(tasksFilePath, "utf-8");
  return JSON.parse(data);
};

const writeTasksToFile = (tasks) => {
  fs.writeFileSync(tasksFilePath, JSON.stringify(tasks, null, 2));
};

module.exports = { readTasksFromFile, writeTasksToFile };
