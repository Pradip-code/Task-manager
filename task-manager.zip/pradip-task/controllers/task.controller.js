const { v4: uuidv4 } = require("uuid");
const {
  readTasksFromFile,
  writeTasksToFile,
} = require("../helpers/fileHelper");
const { successResponse, errorResponse } = require("../utils/responses");

// Create a task
const createTask = (req, res) => {
  try {
    const { title, description } = req.body;

    if (!title || !description) {
      return errorResponse(res, 400, "Title and description are required");
    }

    const tasks = readTasksFromFile();
    const newTask = {
      id: uuidv4(),
      title,
      description,
      status: "Pending",
    };

    tasks.push(newTask);
    writeTasksToFile(tasks);

    successResponse(res, 201, "Task created successfully", { task: newTask });
  } catch (error) {
    errorResponse(res, 500, "An error occurred while creating the task");
  }
};

// Get all tasks
const getTasks = (req, res) => {
  try {
    const tasks = readTasksFromFile();
    successResponse(res, 200, "Tasks retrieved successfully", tasks);
  } catch (error) {
    errorResponse(res, 500, "An error occurred while retrieving tasks");
  }
};

// Update a task
const updateTask = (req, res) => {
  try {
    const taskId = req.params.id;
    const { status } = req.body;

    const validStatuses = ["Pending", "In Progress", "Completed"];
    if (!validStatuses.includes(status)) {
      return errorResponse(res, 400, "Invalid status value");
    }

    const tasks = readTasksFromFile();
    const taskIndex = tasks.findIndex((task) => task.id === taskId);

    if (taskIndex === -1) {
      return errorResponse(res, 404, "Task not found");
    }

    tasks[taskIndex].status = status;
    writeTasksToFile(tasks);

    successResponse(res, 200, "Task updated successfully", {
      task: tasks[taskIndex],
    });
  } catch (error) {
    errorResponse(res, 500, "An error occurred while updating the task");
  }
};

// Delete a task
const deleteTask = (req, res) => {
  try {
    const taskId = req.params.id;
    const tasks = readTasksFromFile();
    const updatedTasks = tasks.filter((task) => task.id !== taskId);

    if (tasks.length === updatedTasks.length) {
      return errorResponse(res, 404, "Task not found");
    }

    writeTasksToFile(updatedTasks);
    successResponse(res, 200, "Task deleted successfully");
  } catch (error) {
    errorResponse(res, 500, "An error occurred while deleting the task");
  }
};

// Filter tasks by status
const filterTasksByStatus = (req, res) => {
  try {
    const { status } = req.params;
    const validStatuses = ["Pending", "In Progress", "Completed"];

    if (!validStatuses.includes(status)) {
      return errorResponse(res, 400, "Invalid status value");
    }

    const tasks = readTasksFromFile();
    const filteredTasks = tasks.filter((task) => task.status === status);

    successResponse(res, 200, "Tasks filtered successfully", filteredTasks);
  } catch (error) {
    errorResponse(res, 500, "An error occurred while filtering tasks");
  }
};

module.exports = {
  createTask,
  getTasks,
  updateTask,
  deleteTask,
  filterTasksByStatus,
};
